CREATE TRIGGER DO_INSERT
ON DO
AFTER INSERT
AS
UPDATE Orders
SET total = (
			  SELECT SUM(d.price * DO.dishAmount)
			  FROM Dishes d
			  INNER JOIN DO ON DO.dishId = d.dishId
			  WHERE DO.orderId IN (SELECT orderId FROM INSERTED)
			)
WHERE orderId IN (SELECT orderId FROM INSERTED)
INSERT INTO Orders (orderId, total)
SELECT orderId, (
				  SELECT d.price*DO.dishAmount
				  FROM Dishes d
				  INNER JOIN DO ON DO.dishId = d.dishId
				  WHERE DO.orderId IN (SELECT orderId FROM INSERTED)
				)
FROM INSERTED
WHERE NOT EXISTS(SELECT orderId FROM Orders WHERE orderId IN (SELECT orderId FROM INSERTED))
go

